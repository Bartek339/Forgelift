# ForgeFit

## Instalacja
1. W Supabase SQL Editor uruchom `supabase/schema.sql`.
2. W `assets/app.js` podmień `PASTE_SUPABASE_PROJECT_URL` oraz `PASTE_SUPABASE_PUBLISHABLE_KEY` na URL projektu i publishable key.
3. Wgraj pliki do repozytorium GitHub, zachowując strukturę folderów.
4. Netlify: Build command zostaw puste, Publish directory ustaw na `.`.
5. W Supabase Authentication → URL Configuration dodaj URL strony Netlify.

W kodzie frontendu używaj wyłącznie publishable/anon key. Nigdy nie umieszczaj klucza secret/service-role w publicznym repozytorium.

## Obecne funkcje
Logowanie/rejestracja, tworzenie planów i ćwiczeń, sesje, serie z ciężarem/powtórzeniami/RIR/RPE, timer, historia i podstawowe szacowane 1RM. Przypisywanie ćwiczeń do planów, wykresy miesięczne, ranking względem masy ciała i synchronizacja ustawień są do dalszego wdrożenia.
